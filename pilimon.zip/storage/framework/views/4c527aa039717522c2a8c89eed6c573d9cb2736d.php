

<?php $__env->startSection('content'); ?>


<div class = "container-xxl">
    <div class="table-responsive">
        <div class="table-wrapper">
            <div class="table-title">
                    <div class="row">
                        <div class="col-xs-6">
                            <h1 class = text-xl><b>Manage Guides</b></h1>
                        </div>
                        <div class="col-xs-6">
                         <a href="#addGuideModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New Guide</span></a>
                                                    
                        </div>
                    </div>
                </div>
            <table class="table table-sm  datatable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Description</th>
                        <th>Author</th>
						<th>Updated</th>
						<th>Views</th>
						<th>Likes</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>    
    </div>

</div>
    <!-- Add  Modal HTML -->
    <div id="addGuideModal" class="modal fade bd-example-modal-lg">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <form action="/manager/addGuide", method="POST"  class="border border-light p-5">
                    <?php echo csrf_field(); ?>
                        <div class="modal-header">						
                            <h4 class="modal-title">Add Guide Form</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <?php echo $__env->make('dashboard.manager.guideForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="modal-footer">
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
                            <input type="submit" class="btn btn-success" value="Add">
                        </div>
                    </form>
                    <?php if(count($errors) > 0): ?>
                    <script type="text/javascript">
                            $( document ).ready(function() {
                                $('#addGuideModal').modal('show');
                        });
                        </script>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Edit Modal HTML -->
	<div id="editGuideModal" class="modal fade bd-example-modal-lg">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<form action ="<?php echo e(route('guides.update')); ?>" method="POST">
				<?php echo csrf_field(); ?>
					<div class="modal-header">						
						<h4 class="modal-title">Edit Guide</h4>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<input type="text"  hidden name="id" id="eid" required>
					<table class="table table-striped"> 	
					<tr>
					<td colspan="2">
						<div class="form-group">
							<label>Title</label>
							<input type="text" name="title" id="etitle" class="form-control" value="<?php echo e(old('title')); ?>" required >
							<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   			
							<em class="text-danger"> <?php echo e($message); ?></em>
                  			 
              			  	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</td>
					
					
					</tr>
					<tr>
                    <td colspan="2">
						<div class="form-group">
							<label>Category</label>
							<input type="text" name="category" id="ecategory"  class="form-control"  value="<?php echo e(old('category')); ?>" required>
							<?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   			
							<em class="text-danger"> <?php echo e($message); ?></em>
                  		
              			  	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</td>
					
					<tr>
                    <tr>
                    <td colspan="2">
						<div class="form-group">
							<label>Description</label>
							<input type="text" class="form-control" id="edesc" name="desc" value="<?php echo e(old('desc')); ?>" required>
							<?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   			 
							<em class="text-danger"> <?php echo e($message); ?></em>
                  			
              			  	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
           
						</div>
					</td>
                    </tr>
					<td>

                    <div class="form-outline">
                    <label class="form-label" for="textAreaExample2">Content</label>
                          <textarea class="form-control" id="econtent" name = "content" rows="8" value="<?php echo e(old('content')); ?>"></textarea>
                         
                          <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   			 
                    		<em class="text-danger"> <?php echo e($message); ?></em>
                  			
              			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

						
					</td>
                    </tr>
					</table>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-info" value="Save Changes">
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- Delete Modal HTML -->
	<div id="deleteGuideModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<form action="<?php echo e(route('guides.delete')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<?php echo method_field('DELETE'); ?>
					<div class="modal-header">						
						<h4 class="modal-title">Delete Guide</h4>
						<input type="text"  hidden name="id" id="deleteID" required>
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					</div>
					<div class="modal-body">					
						<p>Are you sure you want to delete these Records?</p>
						<p class="text-warning"><small>This action cannot be undone.</small></p>
					</div>
					<div class="modal-footer">
						<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">
						<input type="submit" class="btn btn-danger" value="Delete">
					</div>
				</form>
			</div>
		</div>
	</div>






<script type="text/javascript">
  $(function () {
    
    var table = $('.datatable').DataTable({
   

        "pageLength": 10,
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('guides.list')); ?>",

        columns: [
            {data: 'id', name: 'id'},
            {data: 'title', name: 'title'},
            {data: 'category', name: 'category'},
            {data: 'description', name: 'description'},
            {data: 'fname', name: 'fname'}, 
			{data: 'updated_at', name: 'updated_at'}, 
			{data: 'views', name: 'created_at'}, 
			{data: 'likes', name: 'updated_at'},
            {
                data: 'action', 
                name: 'action', 
                orderable: true, 
                searchable: true
            },
        ]
		
       
    });
    
  });
</script>

<script>
$(document).on('click','.edit',function(){
	var guide_id = $(this).data('id');
	$.get("<?php echo e(route('guides.details')); ?>" ,{guide_id},function(data){
	$("#eid").val(data.details.id);
	$("#etitle").val(data.details.title);
	$("#ecategory").val(data.details.category);
	$("#edesc").val(data.details.description);
	$("#econtent").val(data.details.content);
	},'json');

 
})


$(document).on('click','.delete',function(){
	var guide_id = $(this).data('id');
	$.get("<?php echo e(route('guides.details')); ?>" ,{guide_id},function(data){
	$("#deleteID").val(data.details.id);
	
	},'json');

 
})

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ManagerLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\inese\Documents\Laravel\pilimon\resources\views/dashboard/manager/index.blade.php ENDPATH**/ ?>