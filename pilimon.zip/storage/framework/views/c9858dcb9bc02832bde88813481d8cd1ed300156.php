<table class="table table-striped"> 	
					<tr>
					<td colspan="2">
						<div class="form-group">
							<label>Title</label>
							<input type="text" name="title" id="title" class="form-control" value="<?php echo e(old('title')); ?>" required >
							<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   			
							<em class="text-danger"> <?php echo e($message); ?></em>
                  			 
              			  	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</td>
					
					
					</tr>
					<tr>
                    <td colspan="2">
						<div class="form-group">
							<label>Category</label>
							<input type="text" name="category" id="category"  class="form-control"  value="<?php echo e(old('category')); ?>" required>
							<?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   			
							<em class="text-danger"> <?php echo e($message); ?></em>
                  		
              			  	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</td>
					
					<tr>
                    <tr>
                    <td colspan="2">
						<div class="form-group">
							<label>Description</label>
							<input type="text" class="form-control" id="desc" name="desc" value="<?php echo e(old('desc')); ?>" required>
							<?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   			 
							<em class="text-danger"> <?php echo e($message); ?></em>
                  			
              			  	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
           
						</div>
					</td>
                    </tr>
					<td>

                    <div class="form-outline">
                    <label class="form-label" for="textAreaExample2">Content</label>
                          <textarea class="form-control" id="content" name = "content" rows="8" value="<?php echo e(old('content')); ?>"></textarea>
                         
                          <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   			 
                    		<em class="text-danger"> <?php echo e($message); ?></em>
                  			
              			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

						
					</td>
                    </tr>
					</table><?php /**PATH C:\Users\inese\Documents\Laravel\pilimon\resources\views/dashboard/manager/guideForm.blade.php ENDPATH**/ ?>