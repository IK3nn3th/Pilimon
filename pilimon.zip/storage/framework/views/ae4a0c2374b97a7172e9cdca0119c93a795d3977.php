<html lang="en">
<head>
<title>User Landing Page</title>
	
	<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
    <link rel="stylesheet" href="/css/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="/css/user.css" rel="stylesheet">
<style>

body {
    color: #566787;
    font-family: 'Varela Round', sans-serif;
    font-size: 13px;
}
</style>

</head>
<body class ="backg">

<div class="container">
	<div class="header navbar bdrop">
				<img src="/images/logo_plmun.png" class="logo">
				<nav>
					<ul>
					<li><a>Hello,  <?php echo e($user['fname']); ?>!</a></li>
					<?php if(Auth::user()->role==2): ?>
						<li><a href="<?php echo e(route('manager.dashboard')); ?>">Home </a></li>
						<li><a href="<?php echo e(route('manager.guides')); ?>">View Guides </a></li>
					<?php else: ?>
					<li><a href="<?php echo e(route('user.dashboard')); ?>">Home </a></li>
					<?php endif; ?>
					
						<li> <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
										onclick="event.preventDefault();
														document.getElementById('logout-form').submit();">
											<?php echo e(__('Logout')); ?>

										</a><form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
											<?php echo csrf_field(); ?> 
						</form></li>
					</ul>
				</nav>

	
	</div>
    <div class= bg-white>
    <?php echo $__env->yieldContent('content'); ?>
	<br><br>
    </div>
	<br><br><br><br><br>

</div>
	


</body>
</html><?php /**PATH C:\Users\inese\Documents\Laravel\pilimon\resources\views/layouts/app.blade.php ENDPATH**/ ?>