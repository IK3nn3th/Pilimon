
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Pilimon</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
  
  <link rel="stylesheet" href="/css/style.css">
      
  
</head>
<body>
<div class="login-wrap">
  <div class="login-html">
    <label for="tab-1" class="tab">Sign In</label>
    <div class="login-form">
      <form class="sign-in-htm" action="<?php echo e(route('login')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div>
      <?php if(Session::get('error')): ?>
                   <div class="alert alert-danger" role="alert">
                       <strong><?php echo e(Session::get('error')); ?></strong>
                    </div>
      <?php endif; ?>
      </div>
      <div></br></div>
     
        <div class="group">
          <label for="user" class="label">Email address</label>
          <input id="email" name="email" type="email" class="input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
            </span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="group">
          <label for="pass" class="label">Password</label>
          <input id="password" name="password" type="password" class="input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-type="password"  required autocomplete="current-password">
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
            </span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

         
        </div>
        <div class="form-group form-check">
        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <label class="form-check-label" for="remember">
                    <?php echo e(__('Remember Me')); ?>

                </label>
        </div>
        <div class="group">
          <input type="submit" class="button" value="Sign In">
        </div>
        </br>
        <div class="foot-lnk">
          <a href="#forgot">Forgot Password?</a>
        </div>
        <div class="hr"></div>

        <div class="foot-lnk">
          <a href="<?php echo e(route('register')); ?>">Not yet registered? Sign up!</a>
        </div>
      </form>
    </div>
  </div>
</div>
  
  
</body>
</html><?php /**PATH C:\Users\inese\Documents\Laravel\pilimon\resources\views/auth/login.blade.php ENDPATH**/ ?>