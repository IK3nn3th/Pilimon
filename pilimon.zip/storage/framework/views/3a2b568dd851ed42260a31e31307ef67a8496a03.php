

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class = "sm:grid grid-cols-2 gap-1 w-5/5  py-15 border-b border-gray-200">
        <div class = "mx-auto">
            <img src= "/images/logo_plmun.png" width="200" alt="" class= "object-contain">

        </div>
        <div> 
            <h2 class= "text-5xl font-bold text-white pb-4">
              <?php echo e($guide->title); ?>

            </h2>
            
            <span class = "text-white">
                By <span class = "font-bold  text-black"><?php echo e($guide->fname); ?> <?php echo e($guide->lname); ?></span>, <span class = "font-bold underline"> Last Updated: 
                <?php echo e(date ('jS M Y', strtotime($guide->updated_at))); ?></span>, <span> Views: <?php echo e($guide->views); ?> </span>
            </span> 
           
        
            <p  class= "pt-8 text-white italic text-xl ">
            Category: <?php echo e($guide->category); ?>

            </p>
          
            <p  class= "pt-8 text-gray-700 text-xl pb-10 leading-8 font-light">
            <span class = "font-bold">Description:  </span><?php echo e($guide->description); ?>

            </p>

            <a href="/user/guide/<?php echo e($guide->slug); ?>"
            class = "uppercase bg-blue-500 text-gray-100 text-lg font-extrabold py-4 px-8 rounded-3xl">
            Keep reading
            </a>
        </div>    
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div> 
<?php echo e($guides->links('pagination::bootstrap-4')); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\inese\Documents\Laravel\pilimon\resources\views/dashboard/user/search.blade.php ENDPATH**/ ?>